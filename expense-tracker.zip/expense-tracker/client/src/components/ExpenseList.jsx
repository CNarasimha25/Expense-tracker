import React from 'react'

export default function ExpenseList({ expenses, onEdit, onDelete }){
  if (!expenses || expenses.length === 0) return <p>No expenses yet.</p>

  return (
    <div className="expense-list">
      {expenses.map(e => (
        <div key={e._id} className="expense-item">
          <div>
            <strong>{e.title}</strong>
            <div className="meta">{new Date(e.date).toLocaleDateString()} • {e.category}</div>
          </div>
          <div className="right">
            <div className="amount">₹{e.amount.toFixed(2)}</div>
            <div className="actions">
              <button onClick={()=>onEdit(e)}>Edit</button>
              <button onClick={()=>onDelete(e._id)}>Delete</button>
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}
