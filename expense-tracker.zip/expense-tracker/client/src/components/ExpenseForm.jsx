import React, { useState } from 'react'

export default function ExpenseForm({ onSave, initial }){
  const [title, setTitle] = useState(initial?.title || '');
  const [amount, setAmount] = useState(initial?.amount || '');
  const [category, setCategory] = useState(initial?.category || 'Other');
  const [date, setDate] = useState(initial ? new Date(initial.date).toISOString().slice(0,10) : new Date().toISOString().slice(0,10));
  const [notes, setNotes] = useState(initial?.notes || '');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!title || !amount) return alert('Please enter title and amount');
    onSave({ title, amount: parseFloat(amount), category, date: new Date(date), notes });
    setTitle(''); setAmount(''); setCategory('Other'); setNotes('');
  }

  return (
    <form onSubmit={handleSubmit} className="expense-form">
      <div>
        <input placeholder="Title" value={title} onChange={e=>setTitle(e.target.value)} />
        <input placeholder="Amount" type="number" step="0.01" value={amount} onChange={e=>setAmount(e.target.value)} />
      </div>
      <div>
        <select value={category} onChange={e=>setCategory(e.target.value)}>
          <option>Food</option>
          <option>Transport</option>
          <option>Shopping</option>
          <option>Entertainment</option>
          <option>Bills</option>
          <option>Other</option>
        </select>
        <input type="date" value={date} onChange={e=>setDate(e.target.value)} />
      </div>
      <div>
        <input placeholder="Notes" value={notes} onChange={e=>setNotes(e.target.value)} />
      </div>
      <button type="submit">Save</button>
    </form>
  )
}
