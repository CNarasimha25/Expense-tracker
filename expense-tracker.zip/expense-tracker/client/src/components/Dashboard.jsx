import React from 'react'

export default function Dashboard({ summary }){
  if (!summary) return null;
  const { byCategory, overall } = summary;

  return (
    <div className="dashboard">
      <h3>Overview</h3>
      <div>Total spent: ₹{(overall?.total || 0).toFixed(2)}</div>
      <div>Transactions: {overall?.count || 0}</div>

      <h4>By category</h4>
      <ul>
        {byCategory.map(row => (
          <li key={row._id}>{row._id}: ₹{row.total.toFixed(2)} ({row.count})</li>
        ))}
      </ul>
    </div>
  )
}
