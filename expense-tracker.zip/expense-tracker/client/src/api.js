const API_BASE = '/api/expenses';

export async function fetchExpenses(query = ''){
  const res = await fetch(API_BASE + query);
  return res.json();
}

export async function createExpense(data){
  const res = await fetch(API_BASE, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  });
  return res.json();
}

export async function updateExpense(id, data){
  const res = await fetch(`${API_BASE}/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  });
  return res.json();
}

export async function deleteExpense(id){
  const res = await fetch(`${API_BASE}/${id}`, { method: 'DELETE' });
  return res.json();
}

export async function fetchSummary(){
  const res = await fetch(`${API_BASE}/summary/stats`);
  return res.json();
}
