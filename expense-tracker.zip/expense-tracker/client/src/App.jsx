import React, { useEffect, useState } from 'react'
import { fetchExpenses, createExpense, updateExpense, deleteExpense, fetchSummary } from './api'
import ExpenseForm from './components/ExpenseForm'
import ExpenseList from './components/ExpenseList'
import Dashboard from './components/Dashboard'

export default function App(){
  const [expenses, setExpenses] = useState([])
  const [summary, setSummary] = useState(null)
  const [editing, setEditing] = useState(null)

  const load = async () => {
    const data = await fetchExpenses();
    setExpenses(data);
    const s = await fetchSummary();
    setSummary(s);
  }

  useEffect(()=>{ load(); }, [])

  const handleSave = async (payload) => {
    if (editing) {
      await updateExpense(editing._id, payload);
      setEditing(null)
    } else {
      await createExpense(payload);
    }
    await load();
  }

  const handleEdit = (exp) => setEditing(exp)
  const handleDelete = async (id) => { if (confirm('Delete this expense?')){ await deleteExpense(id); await load(); } }

  return (
    <div className="container">
      <header>
        <h1>Expense Tracker</h1>
      </header>
      <main>
        <div className="left">
          <ExpenseForm onSave={handleSave} initial={editing} />
          <ExpenseList expenses={expenses} onEdit={handleEdit} onDelete={handleDelete} />
        </div>
        <aside className="right">
          <Dashboard summary={summary} />
        </aside>
      </main>
    </div>
  )
}
